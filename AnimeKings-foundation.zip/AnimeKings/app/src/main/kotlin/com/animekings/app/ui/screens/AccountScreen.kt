package com.animekings.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.animekings.app.R
import com.animekings.app.data.models.Profile
import com.animekings.app.data.repository.AuthRepository
import com.animekings.app.ui.theme.TextPrimary
import com.animekings.app.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun AccountScreen(auth: AuthRepository = remember { AuthRepository() }) {
    var profile by remember { mutableStateOf<Profile?>(null) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    suspend fun reloadProfile() {
        runCatching { auth.myProfile() }.onSuccess { profile = it }
    }

    LaunchedEffect(Unit) { reloadProfile() }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        if (profile != null) {
            Text("مرحبًا، ${profile?.displayName ?: "مستخدم"}", color = TextPrimary)
            Text("الدور: ${profile?.role}", color = TextSecondary)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    auth.signOut()
                    profile = null
                }
            }) { Text(stringResource(R.string.logout)) }
        } else {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(stringResource(R.string.email)) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(stringResource(R.string.password)) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                scope.launch {
                    error = runCatching { auth.signIn(email, password); reloadProfile() }
                        .exceptionOrNull()?.message
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.login)) }
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                scope.launch {
                    error = runCatching { auth.signUp(email, password); reloadProfile() }
                        .exceptionOrNull()?.message
                }
            }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.signup)) }

            error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = TextSecondary)
            }
        }
    }
}
