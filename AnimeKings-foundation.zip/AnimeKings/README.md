# Anime KINGS — Foundation

A real (non-static) Android app foundation: Kotlin + Jetpack Compose UI wired
directly to a Supabase backend (Auth + Postgres + Storage), Arabic RTL,
dark/purple-neon theme, matching the requested reference layout.

## What's actually here

**Android app** (`app/`) — Jetpack Compose, RTL forced, dark/neon theme:
- Home: brand top bar (search + notification bell), hero banner, "متابعة المشاهدة"
  (Continue Watching), "الأكثر شعبية" (Most Popular) — both read live from Supabase
  and render an in-language empty state instead of fake placeholder data.
- Movies / Series: grid screens querying `movies` / `series` tables.
- Downloads / Favorites: query the signed-in user's own rows.
- Account: real email/password sign-up, sign-in, sign-out, and profile/role display
  via Supabase Auth — this is a working screen, not a mockup.
- Bottom navigation: Home, Movies, Series, Downloads, Favorites, Account.

**Backend** (`supabase/schema.sql`) — run once on a Supabase project:
- Tables: `profiles`, `anime`, `seasons`, `episodes`, `movies`, `series`,
  `favorites`, `watch_progress`, `views`, `downloads`, `notifications`.
- `app_role` enum (`user`/`admin`) on `profiles`, with a trigger that
  auto-creates a `profiles` row (role `user`) on every signup.
- Row Level Security on every table: public/anon can only read `is_published`
  content; users can only read/write their own `favorites`, `watch_progress`,
  `downloads`; only admins can write catalog content or send notifications.
  Users cannot self-promote to admin (enforced in the `profiles` update policy).
- Two Storage buckets: `covers` (public read, admin write) and `videos`
  (private, admin-only — the app should only ever receive short-lived signed
  URLs for video, never public links).
- `supabase/seed.sql` (optional) adds a few sample rows so Home isn't empty.

## What I could and couldn't verify in this sandbox

This sandbox has **no Android SDK/emulator, no Gradle, and no network access**,
so I could not run `gradle build`, launch an emulator, or provision a live
Supabase project from here — and no reference image was actually attached to
your message, so the design above follows your written description (dark
black/purple neon, hero banner, content cards, etc.) rather than a pixel copy.

What I did verify directly:
- Every generated `.kt`, `.sql`, and `.xml` file has balanced
  braces/parens/brackets (33 files checked, 0 issues).
- Every Kotlin file declares the correct `com.animekings.app` package.
- The schema creates all 11 requested tables, enables RLS on all 11, and
  defines 25 policies covering read/write/owner/admin cases; the two storage
  buckets are created with matching policies.

What still needs a real machine to test:
1. Open this folder in Android Studio (Koala+) — it will resolve Gradle/Compose
   automatically. That first sync is the real build test.
2. Create a Supabase project, run `supabase/schema.sql` in the SQL editor,
   then optionally `supabase/seed.sql`.
3. Put your project's URL and anon key into `gradle.properties` (or pass as
   `-PSUPABASE_URL=... -PSUPABASE_ANON_KEY=...`) — never the `service_role` key.
4. Run the app on a device/emulator, sign up a user, and confirm a matching
   row appears in `profiles` with `role = 'user'`.

## Create your first admin

New signups always get `role = 'user'` (by design — RLS blocks self-promotion).
To create an admin, run this once in the Supabase SQL editor after signing up
normally:

```sql
update public.profiles set role = 'admin' where id = 'THE-USER-UUID';
```

## Next steps (not yet built)
- Search screen, notification list/detail, episode player, actual on-device
  file download pipeline (the `downloads` table exists; there's no
  DownloadManager/WorkManager wiring yet), and an admin content-management UI.
